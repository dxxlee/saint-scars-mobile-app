import 'package:flutter/material.dart';
import '../constants.dart';
import '../models/product.dart';

class ProductDetailPage extends StatefulWidget {
  final Product product;

  const ProductDetailPage({Key? key, required this.product}) : super(key: key);

  @override
  State<ProductDetailPage> createState() => _ProductDetailPageState();
}

class _ProductDetailPageState extends State<ProductDetailPage> {
  late String _selectedSize;
  int _quantity = 1;
  DateTime? _selectedDate;
  TimeOfDay? _selectedTime;

  @override
  void initState() {
    super.initState();
    _selectedSize = widget.product.availableSizes.isNotEmpty
        ? widget.product.availableSizes.first
        : '';
  }

  void _showDeliveryTimeSheet(BuildContext context) async {
    final selectedDate = await showDatePicker(
      context: context,
      initialDate: DateTime.now().add(const Duration(days: 1)),
      firstDate: DateTime.now(),
      lastDate: DateTime.now().add(const Duration(days: 30)),
    );
    if (selectedDate != null) {
      final selectedTime = await showTimePicker(
        context: context,
        initialTime: TimeOfDay.now(),
      );
      setState(() {
        _selectedDate = selectedDate;
        _selectedTime = selectedTime;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final product = widget.product;
    final textTheme = Theme.of(context).textTheme;

    return Scaffold(
      appBar: AppBar(
        title: Text(product.name),
      ),
      body: NestedScrollView(
        headerSliverBuilder: (context, innerBoxIsScrolled) {
          return [
            SliverAppBar(
              pinned: true,
              expandedHeight: 300,
              flexibleSpace: FlexibleSpaceBar(
                title: Text(product.name),
                background: Image.asset(
                  product.imageUrl,
                  fit: BoxFit.cover,
                ),
              ),
            ),
          ];
        },
        body: ListView(
          padding: const EdgeInsets.all(defaultPadding),
          children: [
            // Описание товара
            Text(
              product.description,
              style: textTheme.bodyLarge,
            ),
            const SizedBox(height: defaultPadding),
            // Отображение цены
            Row(
              children: [
                if (product.discountedPrice != null)
                  Text(
                    "\$${product.discountedPrice!.toStringAsFixed(2)}",
                    style: textTheme.titleLarge?.copyWith(
                      color: Colors.redAccent,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                const SizedBox(width: 8),
                Text(
                  "\$${product.price.toStringAsFixed(2)}",
                  style: textTheme.titleMedium?.copyWith(
                    decoration: product.discountedPrice != null
                        ? TextDecoration.lineThrough
                        : null,
                    color: product.discountedPrice != null ? Colors.grey : Colors.black,
                  ),
                ),
              ],
            ),
            const SizedBox(height: defaultPadding),
            // Выбор размера
            Text(
              'Select Size:',
              style: textTheme.titleMedium,
            ),
            const SizedBox(height: 8),
            Row(
              children: product.availableSizes.map((size) {
                final isSelected = _selectedSize == size;
                return Padding(
                  padding: const EdgeInsets.only(right: 8),
                  child: ChoiceChip(
                    label: Text(size),
                    selected: isSelected,
                    onSelected: (selected) {
                      setState(() {
                        _selectedSize = size;
                      });
                    },
                  ),
                );
              }).toList(),
            ),
            const SizedBox(height: defaultPadding),
            // Выбор количества
            Text(
              'Quantity:',
              style: textTheme.titleMedium,
            ),
            const SizedBox(height: 8),
            Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                IconButton(
                  icon: const Icon(Icons.remove),
                  onPressed: () {
                    setState(() {
                      if (_quantity > 1) _quantity--;
                    });
                  },
                ),
                Text('$_quantity', style: textTheme.bodyLarge),
                IconButton(
                  icon: const Icon(Icons.add),
                  onPressed: () {
                    setState(() {
                      _quantity++;
                    });
                  },
                ),
              ],
            ),
            const SizedBox(height: defaultPadding),
            // Кнопка выбора времени доставки через Modal Bottom Sheet
            ElevatedButton(
              onPressed: () => _showDeliveryTimeSheet(context),
              child: const Text('Select Delivery Time'),
            ),
            if (_selectedDate != null && _selectedTime != null)
              Padding(
                padding: const EdgeInsets.only(top: 8),
                child: Text(
                  'Selected: ${_selectedDate!.toLocal().toShortDateString()} at ${_selectedTime!.format(context)}',
                  style: textTheme.bodyMedium,
                ),
              ),
            const SizedBox(height: defaultPadding),
            // Список магазинов
            Text(
              'Available Stores:',
              style: textTheme.titleMedium,
            ),
            const SizedBox(height: 8),
            ...product.availableStores.map((store) {
              return Padding(
                padding: const EdgeInsets.only(bottom: 4),
                child: Row(
                  children: [
                    const Icon(Icons.store, size: 18, color: Colors.grey),
                    const SizedBox(width: 8),
                    Text(store),
                  ],
                ),
              );
            }).toList(),
            const SizedBox(height: defaultPadding * 2),
            // Кнопка "Add to Bag"
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: () {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text('${product.name} added to Bag!')),
                  );
                },
                child: const Text('Add to Bag'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

extension DateFormatExtension on DateTime {
  String toShortDateString() {
    return "${day}/${month}/${year}";
  }
}
