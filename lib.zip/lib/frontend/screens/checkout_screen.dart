import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../models/cart_item.dart';
import '../services/cart_service.dart';
import '../services/order_service.dart';

class CheckoutScreen extends StatefulWidget {
  const CheckoutScreen({Key? key}) : super(key: key);

  @override
  State<CheckoutScreen> createState() => _CheckoutScreenState();
}

class _CheckoutScreenState extends State<CheckoutScreen> {
  final _addrCtrl = TextEditingController();
  String _payment = 'Credit Card';

  @override
  void dispose() {
    _addrCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Checkout')),
      body: StreamBuilder<List<CartItem>>(
        stream: CartService.streamCart(),
        builder: (ctx, snap) {
          if (!snap.hasData) return const Center(child: CircularProgressIndicator());
          final items = snap.data!;
          final total = items.fold<double>(0, (s, e) => s + e.price * e.quantity);

          return Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              children: [
                Expanded(
                  child: ListView(
                    children: items
                        .map((i) => ListTile(
                      title: Text(i.name),
                      trailing: Text('${i.quantity}×\$${i.price}'),
                    ))
                        .toList(),
                  ),
                ),
                TextField(
                  controller: _addrCtrl,
                  decoration: const InputDecoration(labelText: 'Address'),
                ),
                const SizedBox(height: 8),
                DropdownButton<String>(
                  value: _payment,
                  items: ['Credit Card', 'PayPal', 'Cash on Delivery']
                      .map((m) => DropdownMenuItem(value: m, child: Text(m)))
                      .toList(),
                  onChanged: (v) => setState(() => _payment = v!),
                ),
                const SizedBox(height: 16),
                ElevatedButton(
                  onPressed: () async {
                    await OrderService.placeOrder(
                      items: items,
                      address: _addrCtrl.text,
                      paymentMethod: _payment,
                    );
                    await CartService.clear();
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('Order placed!')),
                    );
                    GoRouter.of(context).go('/');
                  },
                  child: const Text('Place Order'),
                )
              ],
            ),
          );
        },
      ),
    );
  }
}
