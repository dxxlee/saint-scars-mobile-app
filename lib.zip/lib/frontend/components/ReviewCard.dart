import 'package:flutter/material.dart';
import '../models/review.dart';

class ReviewCard extends StatelessWidget {
  final Review review;

  const ReviewCard({Key? key, required this.review}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    // Пример форматирования поля createdAt (если нужно более дружелюбное время)
    // Иначе можно выводить raw-значение
    final dateText = _formatDate(review.createdAt as String);

    return Card(
      child: ListTile(
        leading: CircleAvatar(
          child: Text(
            review.authorId.isNotEmpty
                ? review.authorId[0].toUpperCase()
                : '?',
          ),
        ),
        title: Text(review.authorId),
        subtitle: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(review.content),
            const SizedBox(height: 4),
            Text('Product ID: ${review.productId}'),
            const SizedBox(height: 4),
            Text('Created: $dateText'),
          ],
        ),
      ),
    );
  }

  // Пример, как можно «обрезать» дату
  String _formatDate(String isoString) {
    if (isoString.isEmpty) return 'unknown';
    // Допустим, формат "2025-04-15T15:27:12.123Z"
    // Можно парсить через DateTime.parse(isoString)
    try {
      final dt = DateTime.parse(isoString);
      return '${dt.year}-${dt.month.toString().padLeft(2,'0')}-${dt.day.toString().padLeft(2,'0')} '
          '${dt.hour.toString().padLeft(2,'0')}:${dt.minute.toString().padLeft(2,'0')}';
    } catch (e) {
      return isoString; // fallback
    }
  }
}
