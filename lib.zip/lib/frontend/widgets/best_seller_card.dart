import 'package:flutter/material.dart';
import '../models/product.dart';
import '../screens/product_detail_page.dart';

class BestSellerCard extends StatelessWidget {
  final Product product;

  const BestSellerCard({Key? key, required this.product}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => ProductDetailPage(product: product),
          ),
        );
      },
      child: Card(
        elevation: 2,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            // Верхняя часть карточки с изображением и кнопкой избранного
            Stack(
              children: [
                ClipRRect(
                  borderRadius: const BorderRadius.vertical(
                    top: Radius.circular(16),
                  ),
                  child: AspectRatio(
                    aspectRatio: 2, // соотношение 2:1
                    child: Image.asset(
                      product.imageUrl,
                      fit: BoxFit.fitWidth,
                    ),
                  ),
                ),
                // Whishlist button
                Positioned(
                  top: 8,
                  right: 8,
                  child: IconButton(
                    icon: const Icon(Icons.favorite_border),
                    color: Colors.redAccent,
                    onPressed: () {
                      // Пока не реализовано — просто выводим сообщение
                      debugPrint('Favorite pressed for ${product.name}');
                    },
                  ),
                ),
              ],
            ),
            // Нижняя часть карточки с информацией о товаре
            ListTile(
              title: Text(
                product.name,
                style: Theme.of(context).textTheme.titleSmall,
              ),
              subtitle: Text(
                product.description,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: Theme.of(context).textTheme.bodySmall,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
