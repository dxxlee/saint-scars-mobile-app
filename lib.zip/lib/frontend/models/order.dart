import 'package:cloud_firestore/cloud_firestore.dart';
import 'cart_item.dart';

class Order {
  final String id;
  final List<CartItem> items;
  final double total;
  final String address;
  final String paymentMethod;
  final DateTime createdAt;

  Order({
    required this.id,
    required this.items,
    required this.total,
    required this.address,
    required this.paymentMethod,
    required this.createdAt,
  });

  factory Order.fromDoc(DocumentSnapshot<Map<String, dynamic>> doc, Map<String, dynamic> data) {
    final data = doc.data()!;
    return Order(
      id: doc.id,
      items: (data['items'] as List)
          .map((e) => CartItem.fromJson(e as Map<String, dynamic>))
          .toList(),
      total: (data['total'] as num).toDouble(),
      address: data['address'] as String,
      paymentMethod: data['paymentMethod'] as String,
      createdAt: (data['createdAt'] as Timestamp).toDate(),
    );
  }

  Map<String, dynamic> toJson() => {
    'items': items.map((e) => e.toJson()).toList(),
    'total': total,
    'address': address,
    'paymentMethod': paymentMethod,
    'createdAt': FieldValue.serverTimestamp(),
  };
}
