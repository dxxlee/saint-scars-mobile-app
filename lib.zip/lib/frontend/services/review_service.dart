// lib/services/review_service.dart
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../models/review.dart';

class ReviewService {
  static final _db = FirebaseFirestore.instance;
  static CollectionReference<Map<String, dynamic>> get _col =>
      _db.collection('reviews');

  /// Stream *all* reviews
  static Stream<List<Review>> streamReviews() {
    return _col
        .orderBy('createdAt', descending: true)
        .snapshots()
        .map((snap) => snap.docs.map((doc) {
      final d = doc.data();
      return Review(
        id: doc.id,
        productId: d['productId'] as String,
        authorId: d['authorId'] as String,
        content: d['content'] as String,
        createdAt: (d['createdAt'] as Timestamp).toDate(),
      );
    }).toList());
  }

  /// Stream reviews for one product
  static Stream<List<Review>> streamForProduct(String productId) =>
      _col
          .where('productId', isEqualTo: productId)
          .orderBy('createdAt', descending: true)
          .snapshots()
          .map((snap) => snap.docs.map((doc) {
        final d = doc.data();
        return Review(
          id: doc.id,
          productId: d['productId'] as String,
          authorId: d['authorId'] as String,
          content: d['content'] as String,
          createdAt: (d['createdAt'] as Timestamp).toDate(),
        );
      }).toList());

  /// Add a new review
  static Future<void> addReview({
    required String productId,
    required String content, required String authorId, required String authorName,
  }) {
    final uid = FirebaseAuth.instance.currentUser!.uid;
    return _col.add({
      'productId': productId,
      'authorId': uid,
      'content': content,
      'createdAt': FieldValue.serverTimestamp(),
    });
  }
}
