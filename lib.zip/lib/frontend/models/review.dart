import 'package:cloud_firestore/cloud_firestore.dart';

class Review {
  final String id;
  final String productId;
  final String authorId;
  final String content;
  final DateTime createdAt;

  Review({
    required this.id,
    required this.productId,
    required this.authorId,
    required this.content,
    required this.createdAt,
  });

  factory Review.fromDoc(DocumentSnapshot<Map<String, dynamic>> doc) {
    final data = doc.data()!;
    return Review(
      id: doc.id,
      productId: data['productId'] as String,
      authorId: data['authorId'] as String,
      content: data['content'] as String,
      createdAt: (data['createdAt'] as Timestamp).toDate(),
    );
  }

  Map<String, dynamic> toJson() => {
    'productId': productId,
    'authorId': authorId,
    'content': content,
    'createdAt': FieldValue.serverTimestamp(),
  };
}
