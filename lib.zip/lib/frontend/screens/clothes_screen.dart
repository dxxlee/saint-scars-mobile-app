import 'package:flutter/material.dart';

import '../models/product.dart';
import '../services/product_service.dart';
import '../models/cart_item.dart';
import '../services/cart_service.dart';

class ClothesScreen extends StatelessWidget {
  const ClothesScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<List<Product>>(
      stream: ProductService.streamProducts(),
      builder: (ctx, snap) {
        if (snap.connectionState == ConnectionState.waiting) {
          return const Center(child: CircularProgressIndicator());
        }
        if (snap.hasError) {
          return Center(child: Text('Error: ${snap.error}'));
        }
        final products = snap.data!;

        return ListView.builder(
          itemCount: products.length,
          itemBuilder: (ctx, i) {
            final p = products[i];
            return ListTile(
              leading: Image.network(
                p.imageUrl,
                width: 50,
                height: 50,
                fit: BoxFit.cover,
              ),
              title: Text(p.name),
              subtitle: Text(
                '\$${(p.discountedPrice ?? p.price).toStringAsFixed(2)}',
              ),
              trailing: IconButton(
                icon: const Icon(Icons.add_shopping_cart),
                onPressed: () {
                  final ci = CartItem(
                    productId: p.id,
                    name: p.name,
                    imageUrl: p.imageUrl,
                    price: p.discountedPrice ?? p.price,
                    quantity: 1,
                  );
                  CartService.addToCart(ci);
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Added to cart')),
                  );
                },
              ),
            );
          },
        );
      },
    );
  }
}
