// lib/main.dart

import 'package:clothing_store/frontend/screens/cart_screen.dart';
import 'package:clothing_store/frontend/screens/clothes_screen.dart';
import 'package:clothing_store/frontend/screens/home.dart';
import 'package:clothing_store/frontend/screens/login_screen.dart';
import 'package:clothing_store/frontend/screens/map_screen.dart';
import 'package:clothing_store/frontend/screens/new_review_screen.dart';
import 'package:clothing_store/frontend/screens/not_found_screen.dart';
import 'package:clothing_store/frontend/screens/order_summary_screen.dart';
import 'package:clothing_store/frontend/screens/product_detail_page.dart';
import 'package:clothing_store/frontend/screens/product_detail_screen.dart';
import 'package:clothing_store/frontend/screens/profile_screen.dart';
import 'package:clothing_store/frontend/screens/register_screen.dart';
import 'package:clothing_store/frontend/screens/wishlist_screen.dart';
import 'package:clothing_store/frontend/services/auth_service.dart';
import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_auth/firebase_auth.dart' as fb;
import 'package:go_router/go_router.dart';

import '../firebase_options.dart';
import 'constants.dart';
import 'models/app_user.dart';
import 'models/clothing_category.dart';

import 'models/product.dart';
import 'widgets/app_drawer.dart';
import 'widgets/custom_bottom_nav_bar.dart';

// глобальные нотифаеры для статуса аутентификации и текущего пользователя
final ValueNotifier<bool>    authNotifier  = ValueNotifier<bool>(false);
final ValueNotifier<AppUser?> currentUser  = ValueNotifier<AppUser?>(null);

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);

  // слушаем изменения в Firebase Auth
  AuthService.authStateChanges().listen((fb.User? fbUser) {
    authNotifier.value = fbUser != null;
    currentUser.value = fbUser != null
        ? AppUser.fromFirebase(fbUser)
        : null;
  });

  runApp(const FashionHubApp());
}

class FashionHubApp extends StatefulWidget {
  const FashionHubApp({Key? key}) : super(key: key);

  @override
  State<FashionHubApp> createState() => _FashionHubAppState();
}

class _FashionHubAppState extends State<FashionHubApp> {
  ThemeMode _themeMode         = ThemeMode.light;
  ColorSelection _colorSelected = ColorSelection.pink;
  int _currentIndex            = 0;

  void _changeTheme(bool light) => setState(() => _themeMode   = light ? ThemeMode.light : ThemeMode.dark);
  void _changeColor(int idx)    => setState(() => _colorSelected = ColorSelection.values[idx]);
  void _onTab(int i)            => setState(() => _currentIndex  = i);

  late final GoRouter _router = GoRouter(
    refreshListenable: authNotifier,
    initialLocation: '/',
    routes: [
      // ShellRoute — общий каркас с AppBar, Drawer и BottomNav
      ShellRoute(
        builder: (context, state, child) => Scaffold(
          drawer: const AppDrawer(),
          appBar: AppBar(
            title: const Text('Fashion Hub'),
            automaticallyImplyLeading: false,
            leading: Builder(builder: (ctx) {
              return IconButton(
                icon: const Icon(Icons.menu),
                onPressed: () => Scaffold.of(ctx).openDrawer(),
              );
            }),
            actions: [
              IconButton(
                icon: Icon(_themeMode == ThemeMode.light
                    ? Icons.dark_mode
                    : Icons.light_mode),
                onPressed: () => _changeTheme(_themeMode == ThemeMode.dark),
              ),
              IconButton(icon: const Icon(Icons.search), onPressed: () {}),
            ],
          ),
          body: child,
          bottomNavigationBar: CustomBottomNavBar(
            currentIndex: _currentIndex,
            onTap: (i) {
              _onTab(i);
              switch (i) {
                case 0: context.go('/');          break;
                case 1: context.go('/newreview'); break;
                case 2: context.go('/cart');      break;
                case 3: context.go('/profile');   break;
              }
            },
          ),
          floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
          floatingActionButton: FloatingActionButton(
            onPressed: () => context.push('/newreview'),
            child: const Icon(Icons.add),
          ),
        ),
        routes: [
          GoRoute(
            path: '/',
            builder: (_, __) => HomeScreen(
              changeTheme: _changeTheme,
              changeColor: _changeColor,
              colorSelected: _colorSelected,
            ),
          ),
          GoRoute(path: '/newreview', builder: (_, __) => const NewReviewScreen(productId: '',)),
          GoRoute(path: '/cart',      builder: (_, __) => const CartScreen()),
          GoRoute(path: '/profile',   builder: (_, __) => const ProfileScreen()),
          GoRoute(path: '/wishlist',  builder: (_, __) => const WishlistScreen()),
          GoRoute(path: '/map',       builder: (_, __) => const MapScreen()),
          GoRoute(path: '/clothes-screen', builder: (_, __) => const ClothesScreen())
        ],
      ),

      // Экраны вне ShellRoute
      GoRoute(
        path: '/product',
        builder: (context, state) {
          final Product prod = state.extra as Product;
          return ProductDetailPage(product: prod);
        },
      ),
      GoRoute(
        path: '/category',
        builder: (context, state) {
          final ClothingCategory cat = state.extra as ClothingCategory;
          return ProductDetailScreen(category: cat);
        },
      ),
      GoRoute(path: '/order-summary', builder: (_, __) => const OrderSummaryScreen()),
      GoRoute(path: '/login',         builder: (_, __) => const LoginScreen()),
      GoRoute(path: '/register',      builder: (_, __) => const RegisterScreen()),
    ],

    // Редиректы в зависимости от состояния аутентификации
    redirect: (context, state) {
      final loggedIn = authNotifier.value;
      final goingToLogin    = state.subloc == '/login';
      final goingToRegister = state.subloc == '/register';

      // не залогиненный → /login, если пытается в охраняемые
      if (!loggedIn && ['/cart','/order-summary','/profile'].contains(state.subloc))
        return '/login';
      // залогиненный не должен на /login и /register
      if (loggedIn && (goingToLogin || goingToRegister))
        return '/';
      return null;
    },

    errorBuilder: (_, __) => const NotFoundScreen(),
  );

  @override
  Widget build(BuildContext context) {
    return MaterialApp.router(
      title: 'Fashion Hub',
      themeMode: _themeMode,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.pink, brightness: Brightness.light),
        useMaterial3: true,
      ),
      darkTheme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.pink, brightness: Brightness.dark),
        useMaterial3: true,
      ),
      routerConfig: _router,
    );
  }
}
