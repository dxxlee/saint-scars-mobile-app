import 'package:cloud_firestore/cloud_firestore.dart' as fs;
import '../models/cart_item.dart';
import '../models/order.dart';

class OrderService {
  static final _orders = fs.FirebaseFirestore.instance.collection('orders');

  /// Place a new order document
  static Future<void> placeOrder({
    required List<CartItem> items,
    required String address,
    required String paymentMethod,
  }) {
    final total = items.fold<double>(0, (sum, i) => sum + i.price * i.quantity);
    final order = Order(
      id: '', // Firestore will auto‐generate
      items: items,
      total: total,
      address: address,
      paymentMethod: paymentMethod,
      createdAt: DateTime.now(),
    );
    return _orders.add(order.toJson());
  }

  /// Stream all orders (you can filter by uid inside front‐end if you want)
  static Stream<List<Order>> streamOrders() {
    return _orders
        .orderBy('createdAt', descending: true)
        .snapshots()
        .map((snap) => snap.docs
        .map((doc) => Order.fromDoc(doc.id as fs.DocumentSnapshot<Map<String, dynamic>>, doc.data() as Map<String, dynamic>))
        .toList()
    );
  }
}
