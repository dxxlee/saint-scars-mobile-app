import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:firebase_auth/firebase_auth.dart' as fb;
import '../models/app_user.dart';
import '../services/auth_service.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final fb.User? fbUser = fb.FirebaseAuth.instance.currentUser;
    if (fbUser == null) {
      return Scaffold(
        body: Center(
          child: ElevatedButton(
            onPressed: () => GoRouter.of(context).go('/login'),
            child: const Text('Login'),
          ),
        ),
      );
    }

    final user = AppUser.fromFirebase(fbUser);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Profile'),
        actions: [
          IconButton(
            icon: const Icon(Icons.logout),
            onPressed: () => AuthService.signOut(),
          )
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          CircleAvatar(
            radius: 60,
            backgroundImage: user.photoURL != null
                ? NetworkImage(user.photoURL!)
                : const AssetImage('assets/images/pfp2.jpg')
            as ImageProvider,
          ),
          const SizedBox(height: 16),
          Text(user.displayName ?? 'No name', style: Theme.of(context).textTheme.titleLarge),
          const SizedBox(height: 8),
          Text(user.email, style: Theme.of(context).textTheme.titleMedium),
          const Divider(height: 32),
          ListTile(
            leading: const Icon(Icons.settings),
            title: const Text('Account Settings'),
            onTap: () {},
          ),
          ListTile(
            leading: const Icon(Icons.lock),
            title: const Text('Privacy'),
            onTap: () {},
          ),
          ListTile(
            leading: const Icon(Icons.map),
            title: const Text('Map'),
            onTap: () => GoRouter.of(context).go('/map'),
          ),
        ],
      ),
    );
  }
}
