import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../components/ReviewCard.dart';
import '../components/category_card.dart';
import '../constants.dart';
import '../models/clothing_category.dart';
import '../models/product.dart';
import '../models/review.dart';
import '../services/product_service.dart';
import '../services/review_service.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({
    super.key,
    required this.changeTheme,
    required this.changeColor,
    required this.colorSelected,
  });

  final void Function(bool light) changeTheme;
  final void Function(int idx) changeColor;
  final ColorSelection colorSelected;

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  late final Stream<List<Product>> _productsStream =
  ProductService.streamProducts();
  late final Stream<List<Review>> _reviewsStream =
  ReviewService.streamReviews();

  Widget _topCarousel() {
    final imgs = [
      'assets/images/clothes1.jpg',
      'assets/images/clothes2.jpg',
      'assets/images/nike_shoes.jpg'
    ];
    return PageView.builder(
      itemCount: imgs.length,
      itemBuilder: (_, i) =>
          Image.asset(imgs[i], fit: BoxFit.cover, width: double.infinity),
    );
  }

  Widget _buildCategoryCarousel() {
    final categories = <ClothingCategory>[
      ClothingCategory(
        imageUrl: 'assets/images/men_category.png',
        title: 'Men\'s Wear',
        description: 'Stylish looks for men',
        text: 'Men category details',
      ),
      ClothingCategory(
        imageUrl: 'assets/images/women_category.png',
        title: 'Women\'s Wear',
        description: 'Elegance for women',
        text: 'Women category details',
      ),
      ClothingCategory(
        imageUrl: 'assets/images/shoes_category.jpg',
        title: 'Shoes',
        description: 'Trendy sneakers',
        text: 'Shoes category details',
      ),
    ];
    return SizedBox(
      height: 290,
      child: PageView.builder(
        controller: PageController(viewportFraction: 0.8),
        itemCount: categories.length,
        itemBuilder: (context, index) {
          final category = categories[index];
          return Padding(
            padding: const EdgeInsets.symmetric(horizontal: defaultPadding / 2),
            child: CategoryCard(
              category: category,
              onTap: () => context.push('/category', extra: category),
            ),
          );
        },
      ),
    );
  }

  Widget _buildBestSellersCarousel() {
    return StreamBuilder<List<Product>>(
      stream: _productsStream,
      builder: (_, snap) {
        if (snap.connectionState == ConnectionState.waiting) {
          return const SizedBox(
            height: 250,
            child: Center(child: CircularProgressIndicator()),
          );
        }
        if (snap.hasError) {
          return SizedBox(
            height: 250,
            child: Center(child: Text('Error: ${snap.error}')),
          );
        }
        final products = snap.data!;
        if (products.isEmpty) {
          return const SizedBox(
            height: 250,
            child: Center(child: Text('No products found')),
          );
        }
        return SizedBox(
          height: 240,
          child: PageView.builder(
            controller: PageController(viewportFraction: 0.8),
            itemCount: products.length,
            itemBuilder: (context, i) {
              final product = products[i];
              return Padding(
                padding: const EdgeInsets.symmetric(horizontal: defaultPadding / 2),
                child: InkWell(
                  onTap: () => context.push('/product', extra: product),
                  child: Card(
                    elevation: 2,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(16),
                    ),
                    child: Column(
                      children: [
                        ClipRRect(
                          borderRadius:
                          const BorderRadius.vertical(top: Radius.circular(16)),
                          child: AspectRatio(
                            aspectRatio: 2,
                            child: product.imageUrl.startsWith('http')
                                ? Image.network(product.imageUrl,
                                fit: BoxFit.cover,
                                errorBuilder: (_, __, ___) =>
                                    Container(color: Colors.grey.shade200))
                                : Image.asset(product.imageUrl,
                                fit: BoxFit.cover),
                          ),
                        ),
                        ListTile(
                          title: Text(product.name,
                              style: Theme.of(context).textTheme.titleSmall),
                          subtitle: Text(
                            product.description,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: Theme.of(context).textTheme.bodySmall,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              );
            },
          ),
        );
      },
    );
  }

  Widget _reviewsSection() {
    return StreamBuilder<List<Review>>(
      stream: _reviewsStream,
      builder: (_, snap) {
        if (snap.connectionState == ConnectionState.waiting) {
          return const Center(child: CircularProgressIndicator());
        }
        if (snap.hasError) {
          return Center(child: Text('Error: ${snap.error}'));
        }
        final reviews = snap.data!;
        return Column(
          children: reviews
              .map((r) => Padding(
            padding: const EdgeInsets.only(bottom: defaultPadding),
            child: ReviewCard(review: r),
          ))
              .toList(),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return CustomScrollView(
      slivers: [
        SliverAppBar(
          expandedHeight: 250,
          flexibleSpace: FlexibleSpaceBar(background: _topCarousel()),
        ),
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.all(defaultPadding),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Categories',
                    style: Theme.of(context).textTheme.titleLarge),
                const SizedBox(height: defaultPadding),
                _buildCategoryCarousel(),
                const SizedBox(height: defaultPadding * 1.5),
                Text('Best Sellers',
                    style: Theme.of(context).textTheme.titleLarge),
                const SizedBox(height: defaultPadding),
                _buildBestSellersCarousel(),
                const SizedBox(height: defaultPadding * 1.5),
                Text('Reviews', style: Theme.of(context).textTheme.titleLarge),
                const SizedBox(height: defaultPadding),
                _reviewsSection(),
              ],
            ),
          ),
        ),
      ],
    );
  }
}
