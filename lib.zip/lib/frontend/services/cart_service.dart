import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../models/cart_item.dart';

class CartService {
  static final _db = FirebaseFirestore.instance;

  static CollectionReference<Map<String, dynamic>> get _itemsCol {
    final uid = FirebaseAuth.instance.currentUser!.uid;
    return _db.collection('carts').doc(uid).collection('items');
  }

  /// Поток текущих элементов корзины
  static Stream<List<CartItem>> streamCart() {
    return _itemsCol
        .snapshots()
        .map((snap) => snap.docs.map((doc) => CartItem.fromJson({
      'productId': doc.id,
      ...doc.data(),
    })).toList());
  }

  /// Добавить товар в корзину (или перезаписать)
  static Future<void> addToCart(CartItem item) {
    return _itemsCol.doc(item.productId).set(item.toJson());
  }

  /// Обновить количество
  static Future<void> updateQuantity(String productId, int quantity) {
    return _itemsCol.doc(productId).update({'quantity': quantity});
  }

  /// Удалить товар
  static Future<void> remove(String productId) {
    return _itemsCol.doc(productId).delete();
  }

  /// Очистить корзину
  static Future<void> clear() async {
    final batch = _db.batch();
    final snaps = await _itemsCol.get();
    for (var doc in snaps.docs) batch.delete(doc.reference);
    return batch.commit();
  }
}
